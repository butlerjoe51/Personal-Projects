/**
 *
 */
public class Qualification {
//setting up fields and creating the array list
    private String degreeType;
    private String degreeName;
    private String college;
    private String conferringYear;


    Qualification(String degreeType, String degreeName, String college, String conferringYear) {
this.degreeType = degreeType;
this.degreeName=degreeName;
this.college=college;
this.conferringYear=conferringYear;
    }

//getters and setters
    public String getDegreeType(){
        return this.degreeType;
    }

    public void setDegreeType() {
        this.degreeType = degreeType;
    }

    public String getDegreeName() {
        return this.degreeName;
    }

    public void setDegreeName() {
        this.degreeName = degreeName;

    }

    public String getCollege(){
        return this.college;
    }

    public void setCollege(){
        this.college=college;
    }

    public String getConferringYear(){
        return this.conferringYear;
    }

    public void setConferringYear(){
        this.conferringYear=conferringYear;
    }
//converting to string
    public String toString(){  return degreeType + degreeName + college + conferringYear + "\n";} ;


}

