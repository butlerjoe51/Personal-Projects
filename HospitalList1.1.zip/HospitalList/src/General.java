import java.util.ArrayList;

public class General extends RegisteredDoctor {
    /**
     * @param name - the name of the doctor
     * @param dob - the doctor's date of birth
     * @param gender - the doctor's gender
     * @param address - the doctor's address
     * @param contactNumber - the doctor's contact number
     * @param qualifiedInIreland - whether or not the doctor is qualified in Ireland
     * @param qualifications - the doctor's qualifications
     */
    //Creating object
    General(String name, String dob, char gender, String address, String contactNumber, ArrayList<Qualification> qualifications, boolean qualifiedInIreland) {
        super(name, dob, gender, address, contactNumber, qualifiedInIreland, qualifications);
    }
//Override from super
    @Override
    public double calcRegistrationFee() {
        if (qualifiedInIreland() == true) {
            return 194;
        } else {
            return 410;
        }
    }

    @Override
    public String viewContactDetails() {
        String contactDetails = super.viewContactDetails();
        return contactDetails;
    }

    @Override
    public void add(Doctor doctors) {

    }

    @Override
    public int getRegisterationFee() {
        if (qualifiedInIreland() == true) {
            return 194;
        } else {
            return 410;
        }
    }
//Converts to string
    public String toString(){return super.toString();}

}

