//import scanner library
import java.util.Scanner;
//handling exceptions
public class ScannerInput {


    public static int readNextInt(String prompt) {
        do {
            var scanner = new Scanner(System.in);
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.next());
            }
            catch (NumberFormatException e) {
                System.err.println("\tEnter a number please.");
            }
        }  while (true);
    }

    public static double readNextDouble(String prompt) {
        do {
            var scanner = new Scanner(System.in);
            try{
                System.out.print(prompt);
                return Double.parseDouble(scanner.next());
            }
            catch (NumberFormatException e) {
                System.err.println("\tEnter a number please.");
            }
        }  while (true);
    }

    public static String readNextString(String prompt) {

            var scanner = new Scanner(System.in);
                System.out.print(prompt);
                return scanner.next();

    }

    public static String readNextLine(String prompt) {

        var scanner = new Scanner(System.in);
        System.out.print(prompt);
        return scanner.nextLine();

    }


    public static char readNextChar(String prompt) {

        var scanner = new Scanner(System.in);
        System.out.print(prompt);
        return scanner.next().charAt(0);

    }
}
