import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.util.ArrayList;

public class DoctorAPI {
    String doc1 ="";
    private ArrayList<Doctor> doctors = new ArrayList<>();

    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }

    public int numberOfDoctors() {
        return doctors.size();
    }

    public Doctor getDoctor(int numberOfDoctors) {
//...check if passed index is in array list before accessing array list
            // if not, return null
            if (numberOfDoctors >=0 && numberOfDoctors < doctors.size()) {
                return doctors.get(numberOfDoctors);
            }
            else {
                return null;
            }
        }

    boolean removeDoctor(int numberOfDoctors) {
        //..check if passed index is in array list before accessing array list
        // if not, return false
        if (numberOfDoctors >= 0 && numberOfDoctors < doctors.size()) {
            doctors.remove(numberOfDoctors);
            return true;
        } else {
            return false;
        }
    }
//Creating a list of doctors
    public String listOfDoctors() {
        String list = "";

        for (int i =0; i < numberOfDoctors(); i++) {
            list = list + i + ": " + doctors.get(i).toString() + "\n"; }

        if (numberOfDoctors()== 0) {
            return "There are no Doctors"; }
        else { return list; }
    }
//Creating a list of doctors based on type
public String listofDoctors(String docType) {

    String listOfDoctors = "";
    for (int i = 0; i < doctors.size();
         i++) {

        if (doctors.get(i) instanceof Intern && docType.equalsIgnoreCase("Intern")) {
            listOfDoctors = listOfDoctors + i + ": " + doctors.get(i).toString() + "\n";
        } else if (doctors.get(i) instanceof General && docType.equalsIgnoreCase("General")) {
            listOfDoctors = listOfDoctors + i + ": " + doctors.get(i).toString() + "\n";
        } else if (doctors.get(i) instanceof Specialist && docType.equalsIgnoreCase("Specialist")) {
            listOfDoctors = listOfDoctors + i + ": " + doctors.get(i).toString() + "\n";
        }

    }
    if(numberOfDoctors()==0) {
       return "There are no Doctor-type doctors";
        }
    else {return listOfDoctors;}


}


//Searches doctors by their names
ArrayList<Doctor> searchDoctorsbyName(String docName){
    ArrayList<Doctor> listOfNames = new ArrayList<>();
    for (int i = 0; i < doctors.size(); i++) {
      if(doctors.get(i).getName().equalsIgnoreCase(docName)){
      listOfNames.add(doctors.get(i));
      }
    }
    if(doctors.size()==0){
     return null;
    }
    else{
    return listOfNames; }
}
//Searches doctors by their addresses
    ArrayList<Doctor> searchDoctorsbyAddress(String docAdd){
        ArrayList<Doctor> listOfAdds = new ArrayList<>();
        for (int i = 0; i < doctors.size(); i++) {
            if(doctors.get(i).getAddress().equalsIgnoreCase(docAdd)){
                listOfAdds.add(doctors.get(i));
            }
        }
        if(doctors.size()==0){
            return null;
        }
        else{
            return listOfAdds; }
    }
//Searches doctors by their contact number
    ArrayList<Doctor> searchDoctorsbyContactNo(String docNo){
        ArrayList<Doctor> listOfNos = new ArrayList<>();
        for (int i = 0; i < doctors.size(); i++) {
            if(doctors.get(i).getAddress().equalsIgnoreCase(docNo)){
                listOfNos.add(doctors.get(i));
            }
        }
        if(doctors.size()==0){
            return null;
        }
        else{
            return listOfNos; }
    }
//Searches doctors by their gender
    ArrayList<Doctor> searchDoctorsbyGender(char docGen){
        ArrayList<Doctor> listOfGens = new ArrayList<>();
        for (int i = 0; i < doctors.size(); i++) {
            if(doctors.get(i).getAddress().equals(docGen)){
                listOfGens.add(doctors.get(i));
            }
        }
        if(doctors.size()==0){
            return null;
        }
        else{
            return listOfGens; }
    }
//Calculates annual fees
public int calculateAnnualFees()
{
    int fees = 0;
    for (int i = 0; i < doctors.size(); i++) {

        fees = fees + doctors.get(i).getRegisterationFee();
    }
    return fees;
}

    //load and save to XML
    public void load () throws Exception
    {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("Doctors.xml"));
        doctors = (ArrayList<Doctor>) is.readObject();
        is.close();
    }

    public void save () throws Exception
    {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("Doctors.xml"));
        out.writeObject(doctors);
        out.close();
    }
}







