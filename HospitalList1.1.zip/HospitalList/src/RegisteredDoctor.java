import java.util.ArrayList;

public abstract class RegisteredDoctor extends Doctor {
    private boolean qualifiedInIreland;
    /**
     * @param name - the name of the doctor
     * @param dob - the doctor's date of birth
     * @param gender - the doctor's gender
     * @param address - the doctor's address
     * @param contactNumber - the doctor's contact number
     * @param qualifiedInIreland - whether or not the doctor is qualified in Ireland
     * @param qualifications - the doctor's qualifications
     */
    RegisteredDoctor(String name, String dob, char gender, String address, String contactNumber, boolean qualifiedInIreland, ArrayList<Qualification> qualifications){
        super(name, dob, gender, address, contactNumber, qualifications);
        this.qualifiedInIreland = qualifiedInIreland;
    }

    public boolean qualifiedInIreland() {
    return qualifiedInIreland;
    }

   void setQualifiedInIreland(){
        this.qualifiedInIreland=qualifiedInIreland;
    }

public String toString(){return super.toString()+ "Qualified in Ireland" +  qualifiedInIreland + "\n";}

}
