//import libraries
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Scanner;



public class Driver {

    //Setting up fields and driver constructor
    private Scanner input = new Scanner(System.in);
    private DoctorAPI doctors = new DoctorAPI();

    public Driver() {

        runMenu();
    }

    public static void main(String[] args) {
        new Driver();
    }

    /*
     * mainMenu() - This method displays the menu for the application,
     * reads the menu option that the user entered and returns it.
     *
     * @return the users menu choice
     */
    private int mainMenu() {
        System.out.println("Medical Council Menu");
        System.out.println("-----------------------");
        System.out.println("  1) Add a Doctor");
        System.out.println("  2) List all Doctors");
        System.out.println("  3) List Doctors by name");
        System.out.println("  4) Update doctor details");
        System.out.println("  5) Update doctor qualifications");
        System.out.println("  6) Update Doctor specialisms");
        System.out.println("  7) Delete Doctor");
        System.out.println("  --------------------");
        System.out.println("  8)  List Doctors by Contact Number");
        System.out.println("  9)  List Doctors by address");
        System.out.println("  10) Annual Fees Report");
        System.out.println("  11) Doctor report (by category)");
        System.out.println("  12) Doctor Summary report");
        System.out.println("  13) List Doctors by gender");
        System.out.println("  --------------------");
        System.out.println("  20) Save to XML");
        System.out.println("  21) Load from XML");
        System.out.println("  --------------------");
        System.out.println("  0) Exit");
        return ScannerInput.readNextInt("==>>");
    }

    //run main menu
    private void runMenu() {
        int option = mainMenu();
        while (option != 0) {

            switch (option) {
                case 1:
                    addDoctor();
                    break;
                case 2:
                    listDoctors();
                    break;
                 case 3:
                    listDoctorsByName();
                    break;
                case 4:
                    updateDoctor();
                    break;
                case 5:
                    updateDoctorQual();
                    break;
                case 6:
                    updateDocSpec();
                    break;
                case 7:
                    removeDoctor();
                    break;
                case 8:
                    listDoctorsByContactNumber();
                    break;
                case 9:
                    listDoctorsByAddress();
                    break;
                case 10:
                    feesReport();
                    break;
                case 11:
                    doctorReportByCat();
                    break;
                case 12:
                    doctorSummary();
                    break;
                case 13:
                    listDoctorsByGender();
                case 20:
                    try {
                        doctors.save();
                    } catch (Exception e) {
                        System.err.println("Error writing to file: " + e);
                    }
                    break;
                case 21:
                    try {
                        doctors.load();
                    } catch (Exception e) {
                        System.err.println("Error reading from file: " + e);
                    }
                    break;
                default:
                    System.out.println("Invalid option entered: " + option);
                    break;
            }

            //pause the program so that the user can read what we just printed to the terminal window
            System.out.println("\nPress any key to continue...");
            input.nextLine();

            //display the main menu again
            option = mainMenu();
        }

        //the user chose option 0, so exit the program
        System.out.println("Exiting... bye");
        System.exit(0);
    }

    public void addDoctor() {
        //gather the doctor data from the user and create a new doctor.

        System.out.print("Please enter the details of the Doctor:  "+"\n");


        String name = ScannerInput.readNextLine("Enter the Doctor's Name:  ");

        String dob = ScannerInput.readNextLine("Enter the Doctor's Date of Birth: ");

        String address = ScannerInput.readNextLine("Enter the Doctor's Address: ");

        char gender = ScannerInput.readNextChar("Enter the Doctor's Gender: ");

        String contactNumber = ScannerInput.readNextString("Enter the Doctor's Phone Number: ");


        //Use ArrayList or List
        ArrayList<Qualification> qualifications = new ArrayList<>();
        int numQualifications;
        numQualifications = ScannerInput.readNextInt("Enter the number of Qualifications:  ");

         for (int i = 0; i < numQualifications; i++) {
            String degreeName = ScannerInput.readNextLine("Enter Qualification name:  ");

            String degreeType = ScannerInput.readNextLine("Enter the Qualification Type:  ");

            String college = ScannerInput.readNextLine("Enter the College where the Qualification was obtained:  ");

            String conferringYear = ScannerInput.readNextString("Enter the Conferring Year:  ");

            qualifications.add(new Qualification(degreeName, degreeType, college, conferringYear));
        }


        System.out.print("Please enter the type of Doctor (1-Intern 2-General Doctor 3-Specialist Doctor): ");
        int type = input.nextInt();
        if (type == 1) {
         //add intern to our doctorapi obj
            doctors.addDoctor(new Intern (name, dob, gender, address, contactNumber, qualifications)); }
        else if (type == 2) {
            String qualifiedInIreland = ScannerInput.readNextLine("Is the Doctor Qualified in Ireland?:  ");
            boolean qi = false;
            if (qualifiedInIreland.equalsIgnoreCase("yes")) {
                qi = true;
            }
            doctors.addDoctor(new General(name,dob,gender,address,contactNumber,qualifications,qi)); }
          else if (type == 3) {
            String qualifiedInIreland = ScannerInput.readNextLine("Is the Doctor Qualified In Ireland?:  ");
            boolean qi = false;
            if (qualifiedInIreland.equalsIgnoreCase(" yes")) {
                qi = true;
            }

            int numSpecial;
            numSpecial = ScannerInput.readNextInt("How many Specialisms would you like to add?:  ");
            HashSet<String> special = new HashSet<>();

            for (int i = 0; i < numSpecial; i++) {
                String Specialism = ScannerInput.readNextLine("Enter Specialism Name:  ");
                special.add(Specialism);

                doctors.addDoctor(new Specialist(name, dob, gender, address, contactNumber, qi, qualifications, special));
            }
        }

    }
//list doctors
    public void listDoctors(){
    System.out.print(doctors.listOfDoctors());
    }
//list doctors by name, address, contact number and gender
    public void listDoctorsByName() {
        System.out.print("What's the Name of the Doctor you wish to search?:  ");
        String name = ScannerInput.readNextLine("");
        System.out.print(doctors.searchDoctorsbyName(name)); }

     public void listDoctorsByAddress(){
        System.out.print("What is the Address of the Doctor you wish to search?:  ");
        String add =ScannerInput.readNextLine("");
        System.out.print(doctors.searchDoctorsbyAddress(add));
        }

        public void listDoctorsByContactNumber(){
        System.out.print("What is the Contact Number of the Doctor you wish to search?:  ");
        String contact = ScannerInput.readNextLine("");
        System.out.print(doctors.searchDoctorsbyContactNo(contact));
      }

      public void listDoctorsByGender(){
      System.out.print("What is the Gender of the Doctor you wish to search?:  ");
      char gender = ScannerInput.readNextChar("");
      System.out.print(doctors.searchDoctorsbyGender(gender));
      }
//update doctor fields by index
    public void updateDoctor(){
        System.out.print(doctors.listOfDoctors());
       int index = ScannerInput.readNextInt("Select the Index of the Doctor you wish to update:  ");
       int field = ScannerInput.readNextInt("Select the Field you wish to update (1: Name 2: Date of Birth 3: Gender 4: Address 5: Contact Number  ");
       if(field ==1){
           String newName = ScannerInput.readNextLine("Enter the new name: ");
           doctors.getDoctor(index).setName(newName);
       }
       else if(field ==2){
            String newDob = ScannerInput.readNextLine("Enter the new Date of Birth:  ");
            doctors.getDoctor(index).setDob(newDob);
       }

       else if(field ==3){
            char newGender = ScannerInput.readNextChar("Enter the new Gender:  ");
            doctors.getDoctor(index).setGender(newGender);

       }

       else if(field ==4){
            String newAddress = ScannerInput.readNextLine("Enter the new Address:  ");
            doctors.getDoctor(index).setAddress(newAddress);
       }
       else if (field ==5){
            String newContact = ScannerInput.readNextLine("Enter the new Contact Number:  ");
            doctors.getDoctor(index).setContactNumber(newContact);
       }

    }
//update doctor qualifications and specialisms by index
    public void updateDoctorQual(){
        System.out.print(doctors.listOfDoctors());
        int index = ScannerInput.readNextInt("Select the Index of the Doctor you wish to update:  ");
        String newDegType = ScannerInput.readNextLine("Enter the new Degree Type:  ");
        String newDegName = ScannerInput.readNextLine("Enter the new Degree Name");
        String newCollege = ScannerInput.readNextLine("Enter the new College");
        String newConfYear = ScannerInput.readNextLine("Enter the new College");
        doctors.getDoctor(index).addQualification(new Qualification(newDegType, newDegName, newCollege,newConfYear));
    }

    public void updateDocSpec() {
        System.out.print(doctors.listofDoctors("Specialist"));
        int index = ScannerInput.readNextInt("Select the Index of the Doctor you wish to update:  ");
        if(index>=0 && index<doctors.numberOfDoctors()&&doctors.getDoctor(index)instanceof Specialist){
            String newSpec = ScannerInput.readNextLine("Enter the new Specialism:  ");
            ((Specialist) doctors.getDoctor(index)).addSpecialism(newSpec);
        }

    }

    //remove doctor by index
    public void removeDoctor(){
        System.out.println(doctors.listOfDoctors());
        int index = ScannerInput.readNextInt("Select the Index of the Doctor you wish to delete:  ");
        doctors.removeDoctor(index);

    }
//show fees report of all doctors
    public void feesReport() {

        System.out.println(doctors.listOfDoctors());
        double irnFees = 0;
        double specFees =0;
        double genFees =0;
        String listOfDoctors = "";
        for (int i = 0; i < doctors.numberOfDoctors (); i++){
         if(doctors.getDoctor(i) instanceof Intern) {
             irnFees = doctors.getDoctor(i).calcRegistrationFee();
         }
         else if(doctors.getDoctor(i)instanceof General){
             genFees=doctors.getDoctor(i).calcRegistrationFee();
         }
         else if (doctors.getDoctor(i)instanceof Specialist){
             specFees=doctors.getDoctor(i).calcRegistrationFee();
         }
        double total = irnFees+specFees+genFees;

            System.out.println("FEES REPORT");
            System.out.println("_____________________________________________________________");
            System.out.println("Registration fees of all Interns:  " + irnFees);
            System.out.println("Registration fees of all General Doctors:  " + genFees);
            System.out.println("Registration fees of all Specialist Doctors:  " +specFees);
            System.out.println("Total fees:  " +total);
        }
    }
//Report all the doctors in a single category
    public void doctorReportByCat(){
        System.out.println("What Category do you wish to see? 1-Intern 2-General 3-Specialist:  ");
        int choice =input.nextInt();
        System.out.println("DOCTOR REPORT");
        System.out.println("_____________");
        for (int i = 0; i < doctors.numberOfDoctors (); i++){
        if(choice ==1) {
            System.out.println(doctors.listofDoctors("Intern"));
        }
        if(choice ==2){
            System.out.println(doctors.listofDoctors("General"));
        }

        if(choice ==3){
            System.out.println(doctors.listofDoctors("Specialist"));
        }


    } }

//Report all doctors
    public void doctorSummary(){

        System.out.println("DOCTOR SUMMARY");
        System.out.println("______________");
        System.out.println(doctors.listofDoctors("Intern"));
        System.out.println(doctors.listofDoctors("General"));
        System.out.println(doctors.listofDoctors("Specialist"));
    }

    }