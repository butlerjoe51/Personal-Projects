public interface iDoctor {
    //calculates registration fees & shows contact details for all Doctors
    double calcRegistrationFee();
    String viewContactDetails();
}
