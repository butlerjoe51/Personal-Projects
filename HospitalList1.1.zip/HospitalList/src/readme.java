/**
 Name: Joseph Butler
 Student Number: 20079994
 Course: Physics for Modern Technology - Year 2
 Purpose of project: To demonstrate inheritance, polymorphism and test based
 programming, using a menu based system in Java.
 Javadoc: file:///C:/Users/butle/Documents/HospitalList/Javadoc/package-summary.html
 **/