import java.util.ArrayList;

public class Intern extends Doctor {
    /**
     * @param name - the name of the doctor
     * @param dob - the doctor's date of birth
     * @param gender - the doctor's gender
     * @param address - the doctor's address
     * @param contactNumber - the doctor's contact number
     */
    //Making an Intern object
    Intern(String name, String dob, char gender, String address, String contactNumber, ArrayList<Qualification>qualifications) {
        super(name, dob, gender, address, contactNumber,qualifications);
    }

    @Override
    public double calcRegistrationFee() {
        return 310;
    }

    @Override
    public String viewContactDetails() {
        return null;
    }

   public String toString(){return super.toString();}

    @Override
    public void add(Doctor doctors) {

    }

    @Override
    public int getRegisterationFee() {
        return 310;
    }


}
