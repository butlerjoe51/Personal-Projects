import java.util.ArrayList;
import java.util.HashSet;

public abstract class Doctor implements iDoctor {

    private String name;
    private String dob;
    private char gender;
    private String address;
    private String contactNumber;
    private ArrayList<Qualification> qualifications = new ArrayList<>();




    /**
     * @param name - the name of the doctor
     * @param dob - the doctor's date of birth
     * @param gender - the doctor's gender
     * @param address - the doctor's address
     * @param contactNumber - the doctor's contact number
     */
    public Doctor(String name, String dob, char gender, String address, String contactNumber, ArrayList<Qualification> qualifications) {

        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.contactNumber = contactNumber;
        this.qualifications = qualifications;
    }



 public String viewContactDetails(){
      return contactNumber;
 }
//getters and setters
public String getName(){
  return name;
}

public void setName(String name){
   this.name=name;
}

public String getDob(){
  return dob;
}
public void setDob( String dob){
   this.dob=dob;
}

public char getGender(){
  return gender;
}

public void setGender(char gender ){
   this.gender=gender;
}

public String getAddress(){
   return address;
}

public void setAddress(String address){
  this.address=address;
}

public String getContactNumber(){
  return contactNumber;
}

public void setContactNumber(String contactNumber){
  this.contactNumber=contactNumber;
}


public void setQualifications(ArrayList<Qualification> qualifications){
 this.qualifications = qualifications;
 }

ArrayList<Qualification> getQualifications()
 { return qualifications;}

 public void addQualification(Qualification q1){
        qualifications.add(q1);
    }



    /**
     * @return
     */
    //Connvert to string, add to doctorAPI & get registeration fees
public String toString() {return "name :" + name +  "DOB: " + dob +  "Gender: " + gender +  "Address:  " + address +  "Contact Number:  " + contactNumber + "\n";}

    public abstract void add(Doctor doctors);

    public abstract int getRegisterationFee();
}






