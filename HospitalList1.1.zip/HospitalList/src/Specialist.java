import java.util.ArrayList;
import java.util.HashSet;


public class Specialist extends RegisteredDoctor {

    private HashSet<String> specialism;

    /**
     * @param name - the name of the doctor
     * @param dob - the doctor's date of birth
     * @param gender - the doctor's gender
     * @param address - the doctor's address
     * @param contactNumber - the doctor's contact number
     * @param qualifications - the doctor's qualifications
     * @param specialists - the doctor's specialisms
     */
    //Creates object
    Specialist(String name, String dob, char gender, String address, String contactNumber, boolean qualififedInIreland, ArrayList<Qualification> qualifications, HashSet<String> specialists) {
        super(name, dob, gender, address, contactNumber, qualififedInIreland, qualifications);
        this.specialism = specialism;
    }
//Override from super
    @Override
    public double calcRegistrationFee() {
        if (qualifiedInIreland() == true) {
            return 425;
        } else {
            return 641;
        }
    }

    @Override
    public String viewContactDetails() {
        String contactDetails = super.viewContactDetails();
        return contactDetails;
    }

    public void addSpecialism(String s1){
        specialism.add(s1);
    }

//Setter and Getter

public HashSet<String> getSpecialism()
{
    return specialism;
}

public void setSpecialism(HashSet<String>specialism)
{
    this.specialism=specialism;
}
//convert to string
public String toString(){return super.toString()+ "Specialisms:"+specialism+"\n";}

//Override from super
    @Override
    public void add(Doctor doctors) {

    }

    @Override
    public int getRegisterationFee() {
        if(qualifiedInIreland() == true){
            return 425;
        }
        else{ return 641;}
    }


}
