import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;

import static org.junit.Assert.*;

public class DoctorAPITest {
    Intern I;
    General G;
    Specialist S;
    DoctorAPI D = new DoctorAPI();



    @Before
    public void setUp() throws Exception {
        //setting up qualifications, specialisms and Doctors
        ArrayList<Qualification> qualifications =new ArrayList<>();
        qualifications.add(new Qualification("bsc","med","wit","2012"));
        qualifications.add(new Qualification("msc","med","ucd","2010"));


        HashSet<String> specialists = new HashSet<>();
        specialists.add("head");
        specialists.add("heart");
     I=new Intern("Jack","13/1/1986",'m',"Cork","0872205432",qualifications);
     G=new General("Laura","01/4/1990",'f',"Waterford","0862254178",qualifications,true);
     S=new Specialist("Chloe","27/2/1985",'f',"Kilkenny","0894254607",true,qualifications,specialists);
D.addDoctor(I);
D.addDoctor(G);
D.addDoctor(S);

    //Setting up Doctor lists


    }

    @After
    public void tearDown() throws Exception {
     I=null;
     G=null;
     S=null;
    }

    @Test
    public void addDoctor() {
        ArrayList<Qualification> q2 =new ArrayList<>();
  D.addDoctor(new Intern("Joe","11/2/1987",'m',"Dublin","0872207789",q2));
    }

    @Test
    public void numberOfDoctors() {

    assertEquals(3,D.numberOfDoctors());
    }

    @Test
    public void getDoctor() {
    assertEquals(D.getDoctor(0).getName(), "Jack");
    }

    @Test
    public void removeDoctor() {
        D.removeDoctor(0);
    assertEquals(2,D.numberOfDoctors());
    }

    @Test
    public void listOfDoctors() {
    D.listOfDoctors();
    assertEquals(3,D.numberOfDoctors());
    }

    @Test
    public void listofDoctors() {
    D.listofDoctors(D.doc1);
    assertEquals(3,D.numberOfDoctors());
    }

    @Test
    public void searchDoctorsbyName() {
        assertEquals(1,D.searchDoctorsbyName("Chloe").size());
    }

    @Test
    public void searchDoctorsbyAddress() {
        assertEquals(1, D.searchDoctorsbyAddress("Waterford").size());
    }

    @Test
    public void searchDoctorsbyContactNo() {
        assertEquals(0,D.searchDoctorsbyContactNo("0872205432").size());
    }

    @Test
    public  void searchDoctorsbyGender(){
        D.searchDoctorsbyGender('m');
        assertEquals(0,D.searchDoctorsbyGender('m').size());
    }

}