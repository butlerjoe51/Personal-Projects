import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class QualificationTest {
    Qualification q1;
    Qualification q2;

    @Before
    public void setUp() throws Exception {
        //Setting up Qualifications
        q1= new Qualification("bsc", "med", "wit", "2009");
        q2 = new Qualification("phd","nurse","ucd","2010");

        ArrayList<Qualification>qualifications=new ArrayList<>();
        qualifications.add(q1);
        qualifications.add(q2);
    }

    @After
    public void tearDown() throws Exception {
        q1=null;
        q2=null;
    }

    @Test
    public void getDegreeType() {
        assertEquals("bsc", q1.getDegreeType()); //expected type
    }

    @Test
    public void setDegreeType() {
        q1.setDegreeType();
        assertEquals("msc",q1.getDegreeType()); //set to msc
    }

    @Test
    public void getDegreeName() {
        assertEquals("med",q1.getDegreeName()); //expected name
        assertEquals("Med",q1.getDegreeName()); //Unexpected capital letter
        assertEquals("meD",q1.getDegreeName()); //Unexpected capital letter
        assertEquals("med",q2.getDegreeName()); //Assigned to wrong qualification
    }

    @Test
    public void setDegreeName() {
        q1.setDegreeName();
        assertEquals("med",q1.getDegreeName());

    }

    @Test
    public void getCollege() {
        assertEquals("wit",q1.getCollege()); //expected college
        assertEquals("Wit",q1.getCollege()); //Unexpected capital letter
        assertEquals("wiT",q1.getCollege()); //Unexpected capital letter
        assertEquals("wit",q2.getCollege()); //Assigned to wrong qualification
    }

    @Test
    public void setCollege() {
      q1.setCollege();
      assertEquals("ucc",q1.getCollege()); //set to ucc
    }

    @Test
    public void getConferringYear() {
        assertEquals("2009",q1.getConferringYear()); //expected year + qualification
        assertEquals("2010",q1.getConferringYear()); //Wrong year + right qualification
        assertEquals("2010",q2.getConferringYear()); //expected year + qualification
        assertEquals("2009",q2.getConferringYear()); //Year/Qualification mismatch
    }

    @Test
    public void setConferringYear() {
     q1.setConferringYear();
     assertEquals("2009",q1.getConferringYear()); //set to 2009
    }
}