import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;

import static org.junit.Assert.*;

public class SpecialistTest {
    Specialist s1;
    Specialist s2;



    @Before
    public void setUp() throws Exception {
        //Setting up qualifications, specialisms and Specialists
        ArrayList<Qualification>qualifications =new ArrayList<>();
        qualifications.add(new Qualification("bsc","med","wit","2012"));
        qualifications.add(new Qualification("msc","med","ucd","2010"));


        HashSet<String>specialists = new HashSet<>();
        specialists.add("head");
        specialists.add("heart");

     s1=new Specialist("John","22/07/1990",'m',"Waterford","0876260172",true,qualifications,specialists);
     s2=new Specialist("Amy","11/3/1989",'f',"Dublin","0894253605",true,qualifications,specialists);
    }




    @After
    public void tearDown() throws Exception {
        s1=null;
        s2=null;
    }


    @Test
    public void getName() {
     assertEquals("John",s1.getName()); //right name, right specialist
     assertEquals("John",s2.getName()); //s1's name on s2
     assertEquals("Luke",s1.getName()); //Wrong name and specialist

    }

    @Test
    public void setName() {
    s1.setName("Luke");
    assertEquals("Luke",s1.getName()); //new name set
    s2.setName("Mary");
    assertEquals("Mary",s1.getName()); //s2 name in s1 - error
    }

    @Test
    public void getDob() {
    assertEquals("22/07/1990",s1.getDob()); //correct dob and specialist
    assertEquals("22/07/1990",s2.getDob()); //s1's dob on s2
    }

    @Test
    public void setDob() {
    s1.setDob("11/9/1989");
    assertEquals("11/9/1989",s1.getDob()); //new dob in s1
    }

    @Test
    public void getGender() {
    assertEquals('m',s1.getGender()); //correct gender and s
    assertEquals('f',s1.getGender()); //wrong gender
    }

    @Test
    public void setGender() {
     s1.setGender('f');
     assertEquals('f',s1.getGender()); //new gender in s1
    }

    @Test
    public void getAddress() {
    assertEquals("Waterford",s1.getAddress()); //correct address and specialist
    assertEquals("Dublin",s1.getAddress()); //s1's address on s2
    }

    @Test
    public void setAddress() {
    s1.setAddress("Cork");
    assertEquals("Cork",s1.getAddress()); //new address in s1
    }

    @Test
    public void getContactNumber() {
     assertEquals("087626268911",s1.getContactNumber());//correct number and specialist
     assertEquals("087626268911",s2.getContactNumber()); //s1 number on s2
    }

    @Test
    public void setContactNumber() {
    s1.setContactNumber("0876665213");
    assertEquals("0876665213",s1.getContactNumber());
    }



   }